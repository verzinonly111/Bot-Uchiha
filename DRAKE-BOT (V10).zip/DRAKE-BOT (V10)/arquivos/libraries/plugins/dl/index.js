"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dl = void 0;

const Dl_ = require("./start.js");
exports.dl = Dl_.default
exports.default = Dl_.default